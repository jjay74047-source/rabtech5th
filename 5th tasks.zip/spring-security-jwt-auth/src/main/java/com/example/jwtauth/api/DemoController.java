package com.example.jwtauth.api;

import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class DemoController {
    @GetMapping("/user/profile")
    public Map<String, String> profile(Authentication authentication) {
        return Map.of("message", "You accessed a protected endpoint",
                "username", authentication.getName());
    }

    @GetMapping("/admin/dashboard")
    public Map<String, String> adminDashboard(Authentication authentication) {
        return Map.of("message", "Welcome to the admin dashboard",
                "username", authentication.getName());
    }
}
