# Spring Security 6 with JWT Token Authentication

A learning/internship project using Spring Boot, Spring Security 6, JWT Bearer tokens, BCrypt, Spring Data JPA, and H2.

## Requirements
- JDK 17 or newer
- Maven 3.8+
- Postman (for API testing)

## Run in VS Code terminal
From the folder containing `pom.xml`:

```powershell
mvn spring-boot:run
```

The API runs at `http://localhost:8080`.

## API endpoints

| Method | Endpoint | Access |
|---|---|---|
| POST | `/api/auth/register` | Public |
| POST | `/api/auth/login` | Public |
| GET | `/api/user/profile` | Valid JWT required |
| GET | `/api/admin/dashboard` | Valid JWT and ADMIN role required |

New registrations receive the `USER` role. The admin endpoint is intentionally denied to normal registered users.

## Postman test sequence
1. Import `postman/Spring-Security-JWT.postman_collection.json`.
2. Send **Register** with a unique username and password of at least 8 characters.
3. Send **Login** using the same credentials. The collection saves the returned token to a collection variable.
4. Send **Protected Profile**. It should return HTTP 200.
5. Send **Profile Without Token**. It should return HTTP 401 with JSON.
6. Send **Admin Dashboard** using a normal USER token. It should return HTTP 403.

## Security notes
- Passwords are stored using BCrypt, not plain text.
- Sessions are stateless; the API uses Bearer tokens.
- The JWT signing secret in `application.properties` is only a demo fallback. Set a strong secret using the `JWT_SECRET` environment variable and never commit production secrets.
- H2 is used to make local setup easy. For production, configure a managed database, HTTPS, secret management, rate limiting, and appropriate token lifecycle/revocation controls.
- Registration currently assigns the `USER` role only. Do not expose a public endpoint that allows clients to assign themselves ADMIN.

## GitHub submission
Suggested repository name: `spring-security-jwt-authentication`

Suggested proof to include:
- `src/main/java/.../security/SecurityConfig.java`
- `JwtAuthenticationFilter.java`, `JwtService.java`
- `CustomUserDetailsService.java`
- `JsonAuthenticationEntryPoint.java`
- `postman/Spring-Security-JWT.postman_collection.json`
- Screenshots of successful registration/login, protected profile, and unauthorized response.
